import java.util.*;
import java.lang.Math;

public class X02 {
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int size;

        size = 5;
        String[] cArrIsbn = new String[size], arrIsbn = new String[size];
        double[] cArrPrice = new double[size];
        int[] arrQty = new int[size];
        double totalPrice;

        totalPrice = 0.0;
        setDefaultCatalog(cArrIsbn, cArrPrice, size);
        setDefaultPreorder(arrIsbn, arrQty, size);
        fillCatalog(cArrIsbn, cArrPrice, size);
        fillPreorder(arrIsbn, arrQty, size);
        totalPrice = getTotalPrice(cArrIsbn, cArrPrice, arrIsbn, arrQty, size);
        System.out.println(toFixed(totalPrice, 2));
    }

    public static void fillCatalog(String[] cArrIsbn, double[] cArrPrice, int size) {
        int c;

        c = 0;
        for (c = 0; c <= size - 1; c++) {
            cArrIsbn[c] = input.nextLine();
            cArrPrice[c] = Double.parseDouble(input.nextLine());
        }
    }

    public static void fillPreorder(String[] arrIsbn, int[] arrQty, int size) {
        int c;

        c = 0;
        boolean keepFilling;

        keepFilling = true;
        do {
            arrIsbn[c] = input.nextLine();
            if (!arrIsbn[c].equals("---")) {
                arrQty[c] = Integer.parseInt(input.nextLine());
                c = c + 1;
            } else {
                keepFilling = false;
            }
        } while (keepFilling);
    }

    public static double getBookPriceWithIsbn(String[] cArrIsbn, double[] cArrPrice, int size, String isbn) {
        boolean found;

        found = false;
        int c;

        c = 0;
        double price;

        price = 0.0;
        while (!found && c < size - 1) {
            if (cArrIsbn[c].equals(isbn)) {
                found = true;
                price = cArrPrice[c];
            } else {
                c = c + 1;
            }
        }

        return price;
    }

    public static double getTotalPrice(String[] cArrIsbn, double[] cArrPrice, String[] arrIsbn, int[] arrQty,
            int size) {
        boolean keepGoing;

        keepGoing = true;
        int c;

        c = 0;
        double totalPrice, itemPrice;

        totalPrice = 0.0;
        while (!arrIsbn[c].equals("---") && c < size) {
            itemPrice = getBookPriceWithIsbn(cArrIsbn, cArrPrice, size, arrIsbn[c]);
            totalPrice = totalPrice + arrQty[c] * itemPrice;
            c = c + 1;
        }

        return totalPrice;
    }

    public static void setDefaultCatalog(String[] cArrIsbn, double[] cArrPrice, int size) {
        int c;

        c = 0;
        for (c = 0; c <= size - 1; c++) {
            cArrIsbn[c] = "";
            cArrPrice[c] = 0.0;
        }
    }

    public static void setDefaultPreorder(String[] arrIsbn, int[] arrQty, int size) {
        int c;

        c = 0;
        for (c = 0; c <= size - 1; c++) {
            arrIsbn[c] = "";
            arrQty[c] = 0;
        }
    }

    private static String toFixed(double value, int digits) {
        return String.format("%." + digits + "f", value);
    }
}
